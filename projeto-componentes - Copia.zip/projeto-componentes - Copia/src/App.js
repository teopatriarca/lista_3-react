import logo from './logo.svg';
import './App.css';
import ComHeader from './components/ComHeader';
import ComFila from './components/ComFila';
import { ToastContainer } from 'react-toastify';


function App() {
  return (
    <div className="App">
      <ToastContainer />
      <ComHeader />
      <ComFila />
    </div>
  )
}

export default App;
