import {useState} from 'react' 
import {toast} from 'react-toastify'
import { ToastContainer } from 'react-toastify';

export default function ComFila(){

  const [nome , setNome] = useState();
  const [endereco , setEndereco] = useState();
  const [cidade , setCidade] = useState();
  const [estado , setEstado] = useState();
  const [telefone , setTelefone] = useState();

  function nomeAlterar(e){
    setNome(e.target.value); 
  }

  function enderecoAlterar(e){
    setEndereco(e.target.value); 
  }

  function cidadeAlterar(e){
    setCidade(e.target.value); 
  }

  function estadoAlterar(e){
    setEstado(e.target.value); 
  }

  function telefoneAlterar(e){
    setTelefone(e.target.value); 
  }

  function enviarValidar(e){
    e.preventDefault()
    if(nome === undefined || nome === "")
      toast.error('Erro! Nome não pode estar vazio')
    if(endereco === undefined || endereco === "")
      toast.error('Erro! Endereço não pode estar vazio')
    if(cidade === undefined || cidade === "")
      toast.error('Erro! Cidade não pode estar vazio')
    if(estado === undefined || estado === "")
      toast.error('Erro! Estado não pode estar vazio')
    if(telefone === undefined || telefone === "")
      toast.error('Erro! Telefone não pode estar vazio')
    else
      toast.success('Dados Cadastrados!')
  }

    return(
      <div class = "info">
        <form onSubmit = {enviarValidar}>
          <div class = "labels">
            <label htmlFor = "nome" >Nome:  </label>
            <label htmlFor = "endereco" >Endereço:  </label>
            <label htmlFor = "cidade" >Cidade:  </label>
            <label htmlFor = "estado" >Estado:  </label>
            <label htmlFor = "telefone" >Telefone: </label>
          </div>
          <div class="inputs">
            <input type = "text" placeholder = "Insira nome" value = {nome} onChange = {nomeAlterar}/> <br /> <br />
            <input type = "text" placeholder = "Endereço" value = {endereco} onChange = {enderecoAlterar}/> <br /> <br />
            <input type = "text" placeholder = "Cidade" value = {cidade} onChange = {cidadeAlterar}/> <br /> <br />
            <input type = "text" placeholder = "Estado" value = {estado} onChange = {estadoAlterar}/> <br /> <br />
            <input type = "text" placeholder = "(xx) 00000-0000" value = {telefone} onChange = {telefoneAlterar} /> <br />
          </div>
          <input class="botao" type = "submit" value = "Cadastrar Cliente"/> <br />
        </form>
      </div>
    )}