import Clock from 'react-live-clock';

export default function Relogio()
{
    return(
        <Clock format={'HH:mm:ss'} ticking={true} timezone={'GMT-3'}/>
    );
}