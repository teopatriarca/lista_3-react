import './ComHeader.css';
import React from "react";
import { AiOutlineAudit } from "react-icons/ai";
import { BsClockHistory } from "react-icons/bs";
import Relogio from './Relogio';

export default function ComHeader(){
    const texto = "Cadastro de Clientes"

    return (
        <div class="header"> 
            <div className="icone">
                <AiOutlineAudit color="#7FFFD4" size="100" />  <h1> {texto} </h1>
            </div>
            
            <div class="relogioLogo">
                <BsClockHistory color="#7FFFD4" size="50" />
            </div>

            <div class="relogioHora">
                <Relogio />
            </div>
        </div> ) 
    }